package com.empleados.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Modul16Nivell1Fase3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
